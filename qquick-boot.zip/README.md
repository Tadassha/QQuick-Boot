# QQuick Boot 
increases the smartphone startup speed by disabling encryption metadata 
# MUST READ 
YOU DO EVERYTHING AT YOUR OWN RISK