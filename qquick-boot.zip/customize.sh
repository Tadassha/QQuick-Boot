ui_print "
   increases phone boot speed
   by disabling encryption metadata 
"
ui_print "
   by ᴛᴀᴅᴀɴᴏ      TG: @Tadassha  
   "
